
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/supabase.dart';
import '../providers/app_providers.dart';
import '../widgets/pro_widgets.dart';

class FamilyAiScreen extends ConsumerStatefulWidget {
  const FamilyAiScreen({super.key});

  @override
  ConsumerState<FamilyAiScreen> createState() => _FamilyAiScreenState();
}

class _FamilyAiScreenState extends ConsumerState<FamilyAiScreen> {
  final inputCtrl = TextEditingController();
  final scrollCtrl = ScrollController();
  final messages = <_AiMessage>[];
  bool sending = false;

  @override
  void dispose() {
    inputCtrl.dispose();
    scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final familyIdAsync = ref.watch(currentFamilyIdProvider);
    return familyIdAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Error: $e')),
      data: (familyId) {
        if (familyId == null || familyId.isEmpty) return const RequireFamily();
        return FutureBuilder<_FamilyAiContext>(
          future: _loadContext(familyId),
          builder: (context, snapshot) {
            final data = snapshot.data;
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                const ProHeader(
                  icon: Icons.auto_awesome_rounded,
                  title: 'IA familiar',
                  subtitle: 'Resumen rápido y sugerencias para el día a día',
                ),
                const SizedBox(height: 12),
                if (snapshot.connectionState == ConnectionState.waiting)
                  const LinearProgressIndicator(),
                if (snapshot.hasError)
                  SectionCard(
                    icon: Icons.error_outline,
                    title: 'No pude leer todos los datos',
                    subtitle: 'Revisa que las tablas principales existen en Supabase.',
                    child: Text(snapshot.error.toString()),
                  ),
                if (data != null) ...[
                  _SummaryCard(data: data),
                  const SizedBox(height: 12),
                  _QuickPromptCard(
                    onPrompt: (prompt) => _ask(prompt, data),
                  ),
                  const SizedBox(height: 12),
                  _AssistantCard(
                    messages: messages,
                    inputCtrl: inputCtrl,
                    sending: sending,
                    onSend: () => _ask(inputCtrl.text, data),
                    scrollCtrl: scrollCtrl,
                  ),
                ],
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _ask(String rawPrompt, _FamilyAiContext data) async {
    final prompt = rawPrompt.trim();
    if (prompt.isEmpty || sending) return;
    setState(() {
      sending = true;
      messages.add(_AiMessage(text: prompt, isUser: true));
      inputCtrl.clear();
    });

    await Future<void>.delayed(const Duration(milliseconds: 180));
    final response = _generateAnswer(prompt, data);

    if (!mounted) return;
    setState(() {
      messages.add(_AiMessage(text: response, isUser: false));
      sending = false;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!scrollCtrl.hasClients) return;
      scrollCtrl.animateTo(
        scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  Future<_FamilyAiContext> _loadContext(String familyId) async {
    final now = DateTime.now();
    final todayKey = _dateKey(now);
    final tomorrowKey = _dateKey(now.add(const Duration(days: 1)));

    final shopping = await _safeSelect('shopping_items', familyId);
    final tasks = await _safeSelect('tasks', familyId);
    final events = await _safeSelect('events', familyId);
    final meals = await _safeSelect('meal_entries', familyId);
    final smartDaily = await _safeSelect('smart_daily_menus', familyId);

    final pendingShopping = shopping.where((row) => !_bool(row['done'] ?? row['is_done'])).toList();
    final pendingTasks = tasks.where((row) => !_bool(row['completed'] ?? row['is_done'])).toList();
    final todayEvents = events.where((row) => _rowDateKey(row['start_at'] ?? row['event_date']) == todayKey).toList();
    final tomorrowEvents = events.where((row) => _rowDateKey(row['start_at'] ?? row['event_date']) == tomorrowKey).toList();
    final todayMeals = meals.where((row) => _rowDateKey(row['day_date']) == todayKey).toList();
    final unconfirmedSmartMenus = smartDaily.where((row) => !_bool(row['shopping_confirmed'])).toList();

    pendingTasks.sort((a, b) => _dateFromRow(a['due_at']).compareTo(_dateFromRow(b['due_at'])));
    todayEvents.sort((a, b) => _dateFromRow(a['start_at'] ?? a['event_date']).compareTo(_dateFromRow(b['start_at'] ?? b['event_date'])));

    return _FamilyAiContext(
      pendingShopping: pendingShopping,
      pendingTasks: pendingTasks,
      todayEvents: todayEvents,
      tomorrowEvents: tomorrowEvents,
      todayMeals: todayMeals,
      unconfirmedSmartMenus: unconfirmedSmartMenus,
    );
  }

  Future<List<Map<String, dynamic>>> _safeSelect(String table, String familyId) async {
    try {
      final rows = await sb.from(table).select('*').eq('family_id', familyId);
      return (rows as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  String _generateAnswer(String prompt, _FamilyAiContext data) {
    final q = prompt.toLowerCase();
    if (q.contains('compra') || q.contains('comprar')) return data.shoppingAdvice;
    if (q.contains('tarea') || q.contains('pendiente')) return data.tasksAdvice;
    if (q.contains('agenda') || q.contains('evento') || q.contains('hoy')) return data.agendaAdvice;
    if (q.contains('menú') || q.contains('menu') || q.contains('comida') || q.contains('cena')) return data.mealsAdvice;
    if (q.contains('resumen') || q.contains('plan')) return data.fullSummary;

    return 'Puedo ayudarte con resumen familiar, compra, tareas, agenda y menús.\n\n${data.fullSummary}';
  }

  static bool _bool(dynamic value) {
    if (value is bool) return value;
    if (value is num) return value != 0;
    final text = value?.toString().toLowerCase().trim();
    return text == 'true' || text == '1' || text == 'yes';
  }

  static DateTime _dateFromRow(dynamic value) {
    return DateTime.tryParse((value ?? '').toString()) ?? DateTime(2999);
  }

  static String _rowDateKey(dynamic value) {
    final date = DateTime.tryParse((value ?? '').toString());
    if (date == null) return '';
    return _dateKey(date.toLocal());
  }

  static String _dateKey(DateTime date) {
    return '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.data});

  final _FamilyAiContext data;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      icon: Icons.psychology_alt_rounded,
      title: 'Resumen inteligente',
      subtitle: 'Vista rápida de lo importante ahora mismo',
      child: Column(
        children: [
          _MetricRow(icon: Icons.shopping_cart_outlined, label: 'Compra pendiente', value: '${data.pendingShopping.length}'),
          _MetricRow(icon: Icons.task_alt_outlined, label: 'Tareas pendientes', value: '${data.pendingTasks.length}'),
          _MetricRow(icon: Icons.event_outlined, label: 'Eventos de hoy', value: '${data.todayEvents.length}'),
          _MetricRow(icon: Icons.restaurant_menu_outlined, label: 'Menús sin confirmar compra', value: '${data.unconfirmedSmartMenus.length}'),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(data.topSuggestion, style: Theme.of(context).textTheme.bodyMedium),
          ),
        ],
      ),
    );
  }
}

class _QuickPromptCard extends StatelessWidget {
  const _QuickPromptCard({required this.onPrompt});

  final ValueChanged<String> onPrompt;

  @override
  Widget build(BuildContext context) {
    final prompts = [
      ('Resumen de hoy', Icons.today_outlined),
      ('Qué falta en compra', Icons.shopping_basket_outlined),
      ('Tareas pendientes', Icons.checklist_rtl_outlined),
      ('Menús y comida', Icons.restaurant_outlined),
    ];
    return SectionCard(
      icon: Icons.bolt_rounded,
      title: 'Preguntas rápidas',
      subtitle: 'Toca una sugerencia o escribe abajo',
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final item in prompts)
            ActionChip(
              avatar: Icon(item.$2, size: 18),
              label: Text(item.$1),
              onPressed: () => onPrompt(item.$1),
            ),
        ],
      ),
    );
  }
}

class _AssistantCard extends StatelessWidget {
  const _AssistantCard({
    required this.messages,
    required this.inputCtrl,
    required this.sending,
    required this.onSend,
    required this.scrollCtrl,
  });

  final List<_AiMessage> messages;
  final TextEditingController inputCtrl;
  final bool sending;
  final VoidCallback onSend;
  final ScrollController scrollCtrl;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      icon: Icons.chat_bubble_outline_rounded,
      title: 'Asistente familiar',
      subtitle: 'De momento trabaja con los datos de la app. Más adelante se puede conectar a IA real por API.',
      child: Column(
        children: [
          SizedBox(
            height: 260,
            child: messages.isEmpty
                ? const EmptyState(
                    icon: Icons.auto_awesome_outlined,
                    title: 'Pregunta algo',
                    message: 'Ejemplo: “hazme un resumen de hoy” o “qué falta en la compra”.',
                  )
                : ListView.builder(
                    controller: scrollCtrl,
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final msg = messages[index];
                      return Align(
                        alignment: msg.isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 520),
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: msg.isUser
                                ? Theme.of(context).colorScheme.primaryContainer
                                : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: SelectableText(msg.text),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: inputCtrl,
                  enabled: !sending,
                  minLines: 1,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.auto_awesome_rounded),
                    labelText: 'Pregunta a la IA familiar',
                  ),
                  onSubmitted: (_) => onSend(),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: sending ? null : onSend,
                child: sending
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.send_rounded),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetricRow extends StatelessWidget {
  const _MetricRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(child: Text(label)),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}

class _AiMessage {
  final String text;
  final bool isUser;
  const _AiMessage({required this.text, required this.isUser});
}

class _FamilyAiContext {
  final List<Map<String, dynamic>> pendingShopping;
  final List<Map<String, dynamic>> pendingTasks;
  final List<Map<String, dynamic>> todayEvents;
  final List<Map<String, dynamic>> tomorrowEvents;
  final List<Map<String, dynamic>> todayMeals;
  final List<Map<String, dynamic>> unconfirmedSmartMenus;

  const _FamilyAiContext({
    required this.pendingShopping,
    required this.pendingTasks,
    required this.todayEvents,
    required this.tomorrowEvents,
    required this.todayMeals,
    required this.unconfirmedSmartMenus,
  });

  String get topSuggestion {
    if (pendingTasks.length >= 3) return 'Tienes bastantes tareas pendientes. Conviene cerrar primero las más antiguas o con fecha cercana.';
    if (pendingShopping.length >= 5) return 'La lista de compra empieza a estar cargada. Puedes revisarla antes de salir de casa.';
    if (todayEvents.isNotEmpty) return 'Hoy hay eventos en agenda. Revisa horarios antes de planificar tareas.';
    if (todayMeals.isEmpty) return 'No hay menú registrado para hoy. Puedes planificar comida y cena para evitar improvisar.';
    return 'Todo parece bastante controlado. Buen momento para revisar menús o adelantar tareas.';
  }

  String get fullSummary {
    return [
      'Resumen de hoy:',
      '• Compra pendiente: ${pendingShopping.length}',
      '• Tareas pendientes: ${pendingTasks.length}',
      '• Eventos de hoy: ${todayEvents.length}',
      '• Menús con compra sin confirmar: ${unconfirmedSmartMenus.length}',
      '',
      topSuggestion,
    ].join('\n');
  }

  String get shoppingAdvice {
    if (pendingShopping.isEmpty) return 'No hay productos pendientes en la compra. La lista está limpia.';
    final names = pendingShopping.take(8).map((e) => _name(e, ['name', 'text'])).where((e) => e.isNotEmpty).join(', ');
    return 'Tienes ${pendingShopping.length} producto(s) pendiente(s).${names.isEmpty ? '' : '\nPrioritarios o recientes: $names.'}\n\nConsejo: antes de confirmar menús con compra, revisa qué tienes ya en casa para no duplicar.';
  }

  String get tasksAdvice {
    if (pendingTasks.isEmpty) return 'No tienes tareas pendientes. Buen momento para crear alguna rutina o preparar la semana.';
    final names = pendingTasks.take(6).map((e) => _name(e, ['title', 'text', 'name'])).where((e) => e.isNotEmpty).join('\n• ');
    return 'Tienes ${pendingTasks.length} tarea(s) pendiente(s).${names.isEmpty ? '' : '\n\n• $names'}';
  }

  String get agendaAdvice {
    final lines = <String>[];
    if (todayEvents.isEmpty) {
      lines.add('Hoy no hay eventos registrados.');
    } else {
      lines.add('Eventos de hoy:');
      for (final e in todayEvents.take(6)) {
        lines.add('• ${_time(e['start_at'] ?? e['event_date'])} ${_name(e, ['title', 'name'])}');
      }
    }
    if (tomorrowEvents.isNotEmpty) {
      lines.add('');
      lines.add('Mañana tienes ${tomorrowEvents.length} evento(s).');
    }
    return lines.join('\n');
  }

  String get mealsAdvice {
    if (todayMeals.isEmpty && unconfirmedSmartMenus.isEmpty) {
      return 'No hay menús registrados para hoy ni compras pendientes de menús. Puedes planificar comida y cena desde Menús o Menús con compra.';
    }
    final lines = <String>[];
    if (todayMeals.isNotEmpty) {
      lines.add('Menú de hoy:');
      for (final meal in todayMeals) {
        lines.add('• ${_mealType(meal['meal_type'])}: ${_name(meal, ['text', 'name'])}');
      }
    }
    if (unconfirmedSmartMenus.isNotEmpty) {
      lines.add('');
      lines.add('Tienes ${unconfirmedSmartMenus.length} día(s)/menú(s) con compra pendiente de confirmar.');
    }
    return lines.join('\n');
  }

  static String _name(Map<String, dynamic> row, List<String> keys) {
    for (final key in keys) {
      final value = row[key]?.toString().trim();
      if (value != null && value.isNotEmpty) return value;
    }
    return '';
  }

  static String _time(dynamic value) {
    final date = DateTime.tryParse((value ?? '').toString());
    if (date == null) return '';
    final local = date.toLocal();
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }

  static String _mealType(dynamic value) {
    switch ((value ?? '').toString()) {
      case 'lunch':
        return 'Comida';
      case 'dinner':
        return 'Cena';
      case 'breakfast':
        return 'Desayuno';
      default:
        return 'Menú';
    }
  }
}
