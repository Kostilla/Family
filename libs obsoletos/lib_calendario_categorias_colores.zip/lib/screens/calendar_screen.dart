import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:table_calendar/table_calendar.dart';

import '../models/app_models.dart';
import '../providers/app_providers.dart';
import '../widgets/pro_widgets.dart';
import 'calendar_categories_screen.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime focusedDay = DateTime.now();
  DateTime selectedDay = DateTime.now();
  final titleCtrl = TextEditingController();
  final notesCtrl = TextEditingController();
  String? selectedCategoryId;

  @override
  void dispose() {
    titleCtrl.dispose();
    notesCtrl.dispose();
    super.dispose();
  }

  List<EventModel> _forDay(List<EventModel> events, DateTime day) {
    return events
        .where((e) =>
            e.startAt.year == day.year &&
            e.startAt.month == day.month &&
            e.startAt.day == day.day)
        .toList()
      ..sort((a, b) => a.startAt.compareTo(b.startAt));
  }

  Map<String, CalendarCategoryModel> _categoryMap(List<CalendarCategoryModel> categories) {
    return {for (final category in categories) category.id: category};
  }

  Color _colorFromHex(String? value, BuildContext context) {
    if (value == null || value.trim().isEmpty) {
      return Theme.of(context).colorScheme.primary;
    }
    final cleaned = value.replaceAll('#', '').trim();
    if (cleaned.length == 6) {
      return Color(int.parse('FF$cleaned', radix: 16));
    }
    if (cleaned.length == 8) {
      return Color(int.parse(cleaned, radix: 16));
    }
    return Theme.of(context).colorScheme.primary;
  }

  Color _eventColor(EventModel event, Map<String, CalendarCategoryModel> categories, BuildContext context) {
    final category = event.categoryId == null ? null : categories[event.categoryId];
    return _colorFromHex(category?.color ?? event.color, context);
  }

  String _categoryName(EventModel event, Map<String, CalendarCategoryModel> categories) {
    final category = event.categoryId == null ? null : categories[event.categoryId];
    return category?.name ?? 'Sin categoría';
  }

  @override
  Widget build(BuildContext context) {
    final currentFamilyAsync = ref.watch(currentFamilyIdProvider);
    final repo = ref.watch(repositoriesProvider);

    return currentFamilyAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Error: $e')),
      data: (familyId) {
        if (familyId == null) return const RequireFamily();
        return StreamBuilder<List<CalendarCategoryModel>>(
          stream: repo.calendarCategories(familyId),
          builder: (context, categorySnapshot) {
            final categories = categorySnapshot.data ?? [];
            final categoryById = _categoryMap(categories);

            if (selectedCategoryId != null && !categoryById.containsKey(selectedCategoryId)) {
              selectedCategoryId = categories.isEmpty ? null : categories.first.id;
            }
            selectedCategoryId ??= categories.isEmpty ? null : categories.first.id;

            return StreamBuilder<List<EventModel>>(
              stream: repo.events(familyId),
              builder: (context, snapshot) {
                final events = snapshot.data ?? [];
                final dayEvents = _forDay(events, selectedDay);

                return ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  children: [
                    ProHeader(
                      icon: Icons.calendar_month_outlined,
                      title: 'Calendario',
                      subtitle: '${events.length} evento(s) familiares',
                      action: IconButton.filledTonal(
                        tooltip: 'Categorías',
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const CalendarCategoriesScreenEntry(),
                          ),
                        ),
                        icon: const Icon(Icons.category_outlined),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: TableCalendar<EventModel>(
                          firstDay: DateTime.utc(2020, 1, 1),
                          lastDay: DateTime.utc(2035, 12, 31),
                          focusedDay: focusedDay,
                          selectedDayPredicate: (d) =>
                              d.year == selectedDay.year &&
                              d.month == selectedDay.month &&
                              d.day == selectedDay.day,
                          eventLoader: (day) => _forDay(events, day),
                          availableCalendarFormats: const {CalendarFormat.month: 'Mes'},
                          calendarStyle: CalendarStyle(
                            markersMaxCount: 0,
                            todayDecoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primaryContainer,
                              shape: BoxShape.circle,
                            ),
                            selectedDecoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                          calendarBuilders: CalendarBuilders<EventModel>(
                            markerBuilder: (context, day, dayEvents) {
                              if (dayEvents.isEmpty) return null;
                              final visible = dayEvents.take(4).toList();
                              return Positioned(
                                bottom: 5,
                                left: 6,
                                right: 6,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    for (final event in visible)
                                      Container(
                                        width: 7,
                                        height: 7,
                                        margin: const EdgeInsets.symmetric(horizontal: 1.5),
                                        decoration: BoxDecoration(
                                          color: _eventColor(event, categoryById, context),
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    if (dayEvents.length > visible.length)
                                      Text(
                                        '+',
                                        style: TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                                        ),
                                      ),
                                  ],
                                ),
                              );
                            },
                          ),
                          onDaySelected: (selected, focused) {
                            setState(() {
                              selectedDay = selected;
                              focusedDay = focused;
                            });
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (categories.isNotEmpty)
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final category in categories)
                            Chip(
                              avatar: CircleAvatar(
                                backgroundColor: _colorFromHex(category.color, context),
                              ),
                              label: Text(category.name),
                            ),
                        ],
                      ),
                    const SizedBox(height: 12),
                    SectionCard(
                      icon: Icons.event_available_outlined,
                      title: 'Nuevo evento',
                      subtitle: '${selectedDay.day}/${selectedDay.month}/${selectedDay.year}',
                      child: Column(
                        children: [
                          TextField(
                            controller: titleCtrl,
                            decoration: const InputDecoration(labelText: 'Título'),
                          ),
                          const SizedBox(height: 8),
                          if (categories.isNotEmpty) ...[
                            DropdownButtonFormField<String>(
                              value: selectedCategoryId,
                              decoration: const InputDecoration(
                                labelText: 'Categoría',
                                prefixIcon: Icon(Icons.category_outlined),
                              ),
                              items: [
                                for (final category in categories)
                                  DropdownMenuItem(
                                    value: category.id,
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 14,
                                          height: 14,
                                          decoration: BoxDecoration(
                                            color: _colorFromHex(category.color, context),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        Text(category.name),
                                      ],
                                    ),
                                  ),
                              ],
                              onChanged: (value) => setState(() => selectedCategoryId = value),
                            ),
                            const SizedBox(height: 8),
                          ] else ...[
                            const Text('Crea categorías en Ajustes para colorear los eventos.'),
                            const SizedBox(height: 8),
                          ],
                          TextField(
                            controller: notesCtrl,
                            decoration: const InputDecoration(labelText: 'Notas'),
                          ),
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton.icon(
                              onPressed: () async {
                                if (titleCtrl.text.trim().isEmpty) return;
                                final start = DateTime(
                                  selectedDay.year,
                                  selectedDay.month,
                                  selectedDay.day,
                                  10,
                                  0,
                                );
                                await repo.addEvent(
                                  familyId: familyId,
                                  title: titleCtrl.text,
                                  notes: notesCtrl.text.trim().isEmpty ? null : notesCtrl.text,
                                  startAt: start,
                                  endAt: start.add(const Duration(hours: 1)),
                                  categoryId: selectedCategoryId,
                                );
                                titleCtrl.clear();
                                notesCtrl.clear();
                              },
                              icon: const Icon(Icons.add),
                              label: const Text('Añadir evento'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (snapshot.connectionState == ConnectionState.waiting)
                      const Center(child: CircularProgressIndicator())
                    else if (dayEvents.isEmpty)
                      const EmptyState(
                        icon: Icons.event_busy_outlined,
                        title: 'Sin eventos ese día',
                        message: 'Añade citas, recordatorios o planes familiares.',
                      )
                    else
                      ...dayEvents.map(
                        (event) {
                          final color = _eventColor(event, categoryById, context);
                          return Card(
                            child: ListTile(
                              leading: Container(
                                width: 14,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: color,
                                  borderRadius: BorderRadius.circular(99),
                                ),
                              ),
                              title: Text(event.title),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(_categoryName(event, categoryById)),
                                  if (event.notes != null && event.notes!.isNotEmpty) Text(event.notes!),
                                ],
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () => repo.deleteEvent(event.id),
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                );
              },
            );
          },
        );
      },
    );
  }
}

// Entrada local para poder abrir la pantalla desde el icono sin depender del router shell.
class CalendarCategoriesScreenEntry extends StatelessWidget {
  const CalendarCategoriesScreenEntry({super.key});

  @override
  Widget build(BuildContext context) => const CalendarCategoriesScreen();
}
