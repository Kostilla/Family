import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/app_models.dart';
import '../providers/app_providers.dart';
import '../widgets/pro_widgets.dart';

class CalendarCategoriesScreen extends ConsumerStatefulWidget {
  const CalendarCategoriesScreen({super.key});

  @override
  ConsumerState<CalendarCategoriesScreen> createState() => _CalendarCategoriesScreenState();
}

class _CalendarCategoriesScreenState extends ConsumerState<CalendarCategoriesScreen> {
  final nameCtrl = TextEditingController();
  String selectedColor = _palette.first;
  CalendarCategoryModel? editing;
  bool saving = false;

  static const _palette = <String>[
    '#EF4444', // rojo
    '#F97316', // naranja
    '#F59E0B', // amarillo
    '#22C55E', // verde
    '#14B8A6', // turquesa
    '#3B82F6', // azul
    '#6366F1', // indigo
    '#A855F7', // violeta
    '#EC4899', // rosa
    '#64748B', // gris
  ];

  @override
  void dispose() {
    nameCtrl.dispose();
    super.dispose();
  }

  Color _colorFromHex(String value) {
    final cleaned = value.replaceAll('#', '').trim();
    if (cleaned.length == 6) return Color(int.parse('FF$cleaned', radix: 16));
    if (cleaned.length == 8) return Color(int.parse(cleaned, radix: 16));
    return Theme.of(context).colorScheme.primary;
  }

  void _startEdit(CalendarCategoryModel category) {
    setState(() {
      editing = category;
      nameCtrl.text = category.name;
      selectedColor = category.color;
    });
  }

  void _clearForm() {
    setState(() {
      editing = null;
      nameCtrl.clear();
      selectedColor = _palette.first;
    });
  }

  Future<void> _save(String familyId, int currentCount) async {
    final name = nameCtrl.text.trim();
    if (name.isEmpty) return;
    setState(() => saving = true);
    try {
      await ref.read(repositoriesProvider).upsertCalendarCategory(
            id: editing?.id,
            familyId: familyId,
            name: name,
            color: selectedColor,
            sortOrder: editing?.sortOrder ?? currentCount,
          );
      _clearForm();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(editing == null ? 'Categoría creada' : 'Categoría guardada')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al guardar categoría: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final familyAsync = ref.watch(currentFamilyIdProvider);
    final repo = ref.watch(repositoriesProvider);

    return Scaffold(
      body: PremiumBackground(
        child: SafeArea(
          child: familyAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('Error: $e')),
            data: (familyId) {
              if (familyId == null) return const RequireFamily();
              return StreamBuilder<List<CalendarCategoryModel>>(
                stream: repo.calendarCategories(familyId),
                builder: (context, snapshot) {
                  final categories = snapshot.data ?? [];
                  return ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    children: [
                      ProHeader(
                        icon: Icons.category_outlined,
                        title: 'Categorías',
                        subtitle: 'Colores para eventos del calendario',
                        action: IconButton.filledTonal(
                          onPressed: () => Navigator.of(context).maybePop(),
                          icon: const Icon(Icons.close),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SectionCard(
                        icon: editing == null ? Icons.add_circle_outline : Icons.edit_outlined,
                        title: editing == null ? 'Nueva categoría' : 'Editar categoría',
                        subtitle: 'El color aparecerá en la vista mensual del calendario',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextField(
                              controller: nameCtrl,
                              decoration: const InputDecoration(
                                labelText: 'Nombre',
                                hintText: 'Trabajo, Médico, Colegio...',
                              ),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 10,
                              runSpacing: 10,
                              children: [
                                for (final color in _palette)
                                  InkWell(
                                    borderRadius: BorderRadius.circular(99),
                                    onTap: () => setState(() => selectedColor = color),
                                    child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 160),
                                      width: 38,
                                      height: 38,
                                      decoration: BoxDecoration(
                                        color: _colorFromHex(color),
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: selectedColor == color
                                              ? Theme.of(context).colorScheme.onSurface
                                              : Colors.transparent,
                                          width: 3,
                                        ),
                                      ),
                                      child: selectedColor == color
                                          ? const Icon(Icons.check, color: Colors.white, size: 20)
                                          : null,
                                    ),
                                  ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            Row(
                              children: [
                                Expanded(
                                  child: FilledButton.icon(
                                    onPressed: saving ? null : () => _save(familyId, categories.length),
                                    icon: const Icon(Icons.save_outlined),
                                    label: Text(saving ? 'Guardando...' : editing == null ? 'Crear categoría' : 'Guardar cambios'),
                                  ),
                                ),
                                if (editing != null) ...[
                                  const SizedBox(width: 8),
                                  IconButton.outlined(
                                    onPressed: saving ? null : _clearForm,
                                    icon: const Icon(Icons.close),
                                  ),
                                ],
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      if (snapshot.connectionState == ConnectionState.waiting)
                        const Center(child: CircularProgressIndicator())
                      else if (categories.isEmpty)
                        const EmptyState(
                          icon: Icons.category_outlined,
                          title: 'Aún no hay categorías',
                          message: 'Crea categorías para colorear los eventos del calendario.',
                        )
                      else
                        ...categories.map(
                          (category) => Card(
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: _colorFromHex(category.color),
                              ),
                              title: Text(category.name),
                              subtitle: Text(category.color),
                              onTap: () => _startEdit(category),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () async {
                                  await repo.deleteCalendarCategory(category.id);
                                  if (editing?.id == category.id) _clearForm();
                                },
                              ),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
