import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/supabase.dart';
import '../models/app_models.dart';
import '../models/module_models.dart';
import '../providers/app_providers.dart';
import '../widgets/pro_widgets.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final chatCtrl = TextEditingController();
  final scrollCtrl = ScrollController();

  @override
  void dispose() {
    chatCtrl.dispose();
    scrollCtrl.dispose();
    super.dispose();
  }

  String _formatTime(DateTime date) {
    final local = date.toLocal();
    final hh = local.hour.toString().padLeft(2, '0');
    final mm = local.minute.toString().padLeft(2, '0');
    return '$hh:$mm';
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!scrollCtrl.hasClients) return;
      scrollCtrl.animateTo(
        scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  FamilySummary? _currentFamily(List<FamilySummary> families, String? id) {
    if (id == null) return null;
    for (final family in families) {
      if (family.id == id) return family;
    }
    return families.isEmpty ? null : families.first;
  }

  @override
  Widget build(BuildContext context) {
    final familiesAsync = ref.watch(myFamiliesProvider);
    final currentFamilyAsync = ref.watch(currentFamilyIdProvider);
    final repo = ref.watch(repositoriesProvider);
    final currentUserId = sb.auth.currentUser?.id;

    return currentFamilyAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Error: $e')),
      data: (familyId) {
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            familiesAsync.when(
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('Error cargando familias: $e'),
              data: (families) {
                final current = _currentFamily(families, familyId);
                return ProHeader(
                  icon: Icons.family_restroom,
                  title: current?.name ?? 'Familia Pro',
                  subtitle: current == null
                      ? 'Crea o elige una familia para empezar.'
                      : 'Rol: ${current.role} · ${families.length} familia(s)',
                  action: IconButton.filledTonal(
                    tooltip: 'Cambiar familia',
                    onPressed: () => context.go('/family-setup'),
                    icon: const Icon(Icons.swap_horiz),
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            if (familyId == null)
              const RequireFamily()
            else ...[
              _QuickActions(familyId: familyId),
              const SizedBox(height: 8),
              Consumer(
                builder: (context, ref, _) {
                  final modulesAsync = ref.watch(familyModulesProvider);
                  return modulesAsync.maybeWhen(
                    data: (modules) => modules.isEnabled('chat')
                        ? _ChatCard(
                            familyId: familyId,
                            currentUserId: currentUserId,
                            chatCtrl: chatCtrl,
                            scrollCtrl: scrollCtrl,
                            formatTime: _formatTime,
                            scrollToBottom: _scrollToBottom,
                          )
                        : const EmptyState(
                            icon: Icons.chat_bubble_outline,
                            title: 'Chat desactivado',
                            message: 'Puedes activarlo en Ajustes → Módulos.',
                          ),
                    orElse: () => _ChatCard(
                      familyId: familyId,
                      currentUserId: currentUserId,
                      chatCtrl: chatCtrl,
                      scrollCtrl: scrollCtrl,
                      formatTime: _formatTime,
                      scrollToBottom: _scrollToBottom,
                    ),
                  );
                },
              ),
            ],
          ],
        );
      },
    );
  }
}

class _QuickActions extends ConsumerWidget {
  const _QuickActions({required this.familyId});

  final String familyId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(repositoriesProvider);
    final modulesAsync = ref.watch(familyModulesProvider);

    return StreamBuilder<List<ShoppingItemModel>>(
      stream: repo.shopping(familyId),
      builder: (context, snapshot) {
        final items = snapshot.data ?? [];
        final pendingShopping = items.where((e) => !e.isDone).length;
        final modules = modulesAsync.maybeWhen(
          data: (value) => value,
          orElse: () => EnabledModules({
            for (final definition in familyModuleDefinitions) definition.key: definition.defaultEnabled,
          }),
        );
        final tiles = <Widget>[
          if (modules.isEnabled('shopping'))
            _ActionTile(
              icon: Icons.shopping_cart_outlined,
              title: 'Compra',
              subtitle: '$pendingShopping pendiente(s)',
              onTap: () => context.go('/shopping'),
            ),
          if (modules.isEnabled('tasks'))
            _ActionTile(
              icon: Icons.checklist_outlined,
              title: 'Tareas',
              subtitle: 'Organización familiar',
              onTap: () => context.go('/tasks'),
            ),
          if (modules.isEnabled('menus'))
            _ActionTile(
              icon: Icons.restaurant_menu_outlined,
              title: 'Menús',
              subtitle: 'Comidas de la semana',
              onTap: () => context.go('/menus'),
            ),
          if (modules.isEnabled('calendar'))
            _ActionTile(
              icon: Icons.calendar_month_outlined,
              title: 'Agenda',
              subtitle: 'Eventos compartidos',
              onTap: () => context.go('/calendar'),
            ),
        ];

        if (tiles.isEmpty) {
          return const EmptyState(
            icon: Icons.dashboard_customize_outlined,
            title: 'Sin módulos activos',
            message: 'Activa módulos desde Ajustes para personalizar el Inicio.',
          );
        }

        return GridView.count(
          crossAxisCount: MediaQuery.sizeOf(context).width > 700 ? 4 : 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 2.25,
          children: tiles,
        );
      },
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return GlassPanel(
      padding: EdgeInsets.zero,
      radius: 24,
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: scheme.primaryContainer.withOpacity(.75), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: scheme.primary)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleSmall),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: scheme.primary),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChatCard extends ConsumerWidget {
  const _ChatCard({
    required this.familyId,
    required this.currentUserId,
    required this.chatCtrl,
    required this.scrollCtrl,
    required this.formatTime,
    required this.scrollToBottom,
  });

  final String familyId;
  final String? currentUserId;
  final TextEditingController chatCtrl;
  final ScrollController scrollCtrl;
  final String Function(DateTime) formatTime;
  final VoidCallback scrollToBottom;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(repositoriesProvider);
    return StreamBuilder<List<ChatMessageModel>>(
      stream: repo.chat(familyId),
      builder: (context, snapshot) {
        if (snapshot.hasData) scrollToBottom();
        final msgs = snapshot.data ?? [];
        return SectionCard(
          icon: Icons.chat_bubble_outline,
          title: 'Chat familiar',
          subtitle: '${msgs.length} mensaje(s)',
          trailing: IconButton(
            tooltip: 'Ajustes de familia',
            onPressed: () => context.go('/settings'),
            icon: const Icon(Icons.group_add_outlined),
          ),
          child: Column(
            children: [
              SizedBox(
                height: 340,
                child: snapshot.connectionState == ConnectionState.waiting
                    ? const Center(child: CircularProgressIndicator())
                    : msgs.isEmpty
                        ? const EmptyState(
                            icon: Icons.forum_outlined,
                            title: 'Empieza la conversación',
                            message: 'Los mensajes se actualizan en tiempo real para toda la familia.',
                          )
                        : ListView.builder(
                            controller: scrollCtrl,
                            itemCount: msgs.length,
                            itemBuilder: (context, index) {
                              final msg = msgs[index];
                              final isMe = msg.createdBy == currentUserId;
                              return Align(
                                alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                                child: ConstrainedBox(
                                  constraints: const BoxConstraints(maxWidth: 460),
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(vertical: 4),
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: isMe
                                          ? Theme.of(context).colorScheme.primaryContainer
                                          : Theme.of(context).colorScheme.surfaceContainerHighest,
                                      borderRadius: BorderRadius.only(
                                        topLeft: const Radius.circular(18),
                                        topRight: const Radius.circular(18),
                                        bottomLeft: Radius.circular(isMe ? 18 : 4),
                                        bottomRight: Radius.circular(isMe ? 4 : 18),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              isMe ? 'Tú' : msg.authorName,
                                              style: Theme.of(context).textTheme.labelMedium,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              formatTime(msg.createdAt),
                                              style: Theme.of(context).textTheme.labelSmall,
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        SelectableText(msg.text),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: chatCtrl,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.message_outlined),
                        labelText: 'Escribe un mensaje',
                      ),
                      onSubmitted: (_) => _send(ref),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () => _send(ref),
                    child: const Icon(Icons.send),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _send(WidgetRef ref) async {
    final text = chatCtrl.text.trim();
    if (text.isEmpty) return;
    await ref.read(repositoriesProvider).sendChat(familyId: familyId, text: text);
    chatCtrl.clear();
    scrollToBottom();
  }
}
