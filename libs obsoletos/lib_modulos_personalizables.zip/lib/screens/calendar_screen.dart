import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:table_calendar/table_calendar.dart';

import '../models/app_models.dart';
import '../providers/app_providers.dart';
import '../widgets/pro_widgets.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime focusedDay = DateTime.now();
  DateTime selectedDay = DateTime.now();
  final titleCtrl = TextEditingController();
  final notesCtrl = TextEditingController();

  @override
  void dispose() {
    titleCtrl.dispose();
    notesCtrl.dispose();
    super.dispose();
  }

  List<EventModel> _forDay(List<EventModel> events, DateTime day) {
    return events
        .where((e) =>
            e.startAt.year == day.year &&
            e.startAt.month == day.month &&
            e.startAt.day == day.day)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final currentFamilyAsync = ref.watch(currentFamilyIdProvider);
    final repo = ref.watch(repositoriesProvider);

    return currentFamilyAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Error: $e')),
      data: (familyId) {
        if (familyId == null) return const RequireFamily();
        return StreamBuilder<List<EventModel>>(
          stream: repo.events(familyId),
          builder: (context, snapshot) {
            final events = snapshot.data ?? [];
            final dayEvents = _forDay(events, selectedDay);

            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                ProHeader(
                  icon: Icons.calendar_month_outlined,
                  title: 'Calendario',
                  subtitle: '${events.length} evento(s) familiares',
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: TableCalendar<EventModel>(
                      firstDay: DateTime.utc(2020, 1, 1),
                      lastDay: DateTime.utc(2035, 12, 31),
                      focusedDay: focusedDay,
                      selectedDayPredicate: (d) =>
                          d.year == selectedDay.year &&
                          d.month == selectedDay.month &&
                          d.day == selectedDay.day,
                      eventLoader: (day) => _forDay(events, day),
                      availableCalendarFormats: const {CalendarFormat.month: 'Mes'},
                      onDaySelected: (selected, focused) {
                        setState(() {
                          selectedDay = selected;
                          focusedDay = focused;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SectionCard(
                  icon: Icons.event_available_outlined,
                  title: 'Nuevo evento',
                  subtitle: '${selectedDay.day}/${selectedDay.month}/${selectedDay.year}',
                  child: Column(
                    children: [
                      TextField(
                        controller: titleCtrl,
                        decoration: const InputDecoration(labelText: 'Título'),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: notesCtrl,
                        decoration: const InputDecoration(labelText: 'Notas'),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () async {
                            if (titleCtrl.text.trim().isEmpty) return;
                            final start = DateTime(
                              selectedDay.year,
                              selectedDay.month,
                              selectedDay.day,
                              10,
                              0,
                            );
                            await repo.addEvent(
                              familyId: familyId,
                              title: titleCtrl.text,
                              notes: notesCtrl.text.trim().isEmpty ? null : notesCtrl.text,
                              startAt: start,
                              endAt: start.add(const Duration(hours: 1)),
                            );
                            titleCtrl.clear();
                            notesCtrl.clear();
                          },
                          icon: const Icon(Icons.add),
                          label: const Text('Añadir evento'),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                if (snapshot.connectionState == ConnectionState.waiting)
                  const Center(child: CircularProgressIndicator())
                else if (dayEvents.isEmpty)
                  const EmptyState(
                    icon: Icons.event_busy_outlined,
                    title: 'Sin eventos ese día',
                    message: 'Añade citas, recordatorios o planes familiares.',
                  )
                else
                  ...dayEvents.map(
                    (event) => Card(
                      child: ListTile(
                        leading: const Icon(Icons.event_note_outlined),
                        title: Text(event.title),
                        subtitle: event.notes == null || event.notes!.isEmpty
                            ? null
                            : Text(event.notes!),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => repo.deleteEvent(event.id),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }
}
