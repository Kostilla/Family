import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'pro_widgets.dart';

class AppShell extends StatelessWidget {
  const AppShell({
    super.key,
    required this.child,
    required this.location,
  });

  final Widget child;
  final String location;

  int _index(String location) {
    if (location.startsWith('/shopping')) return 1;
    if (location.startsWith('/tasks')) return 2;
    if (location.startsWith('/menus')) return 3;
    if (location.startsWith('/calendar')) return 4;
    if (location.startsWith('/settings')) return 5;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final index = _index(location);

    return Scaffold(
      extendBody: true,
      body: PremiumBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 88),
            child: child,
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor.withOpacity(.92),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant.withOpacity(.35)),
              ),
              child: NavigationBar(
                selectedIndex: index,
                onDestinationSelected: (i) {
                  switch (i) {
                    case 0:
                      context.go('/home');
                      break;
                    case 1:
                      context.go('/shopping');
                      break;
                    case 2:
                      context.go('/tasks');
                      break;
                    case 3:
                      context.go('/menus');
                      break;
                    case 4:
                      context.go('/calendar');
                      break;
                    case 5:
                      context.go('/settings');
                      break;
                  }
                },
                destinations: const [
                  NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Inicio'),
                  NavigationDestination(icon: Icon(Icons.shopping_bag_rounded), label: 'Compra'),
                  NavigationDestination(icon: Icon(Icons.task_alt_rounded), label: 'Tareas'),
                  NavigationDestination(icon: Icon(Icons.restaurant_rounded), label: 'Menús'),
                  NavigationDestination(icon: Icon(Icons.calendar_month_rounded), label: 'Agenda'),
                  NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Ajustes'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
