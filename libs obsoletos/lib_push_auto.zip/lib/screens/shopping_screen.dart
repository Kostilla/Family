import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/app_providers.dart';

class ShoppingScreen extends ConsumerStatefulWidget {
  const ShoppingScreen({super.key});

  @override
  ConsumerState<ShoppingScreen> createState() => _ShoppingScreenState();
}

class _ShoppingScreenState extends ConsumerState<ShoppingScreen> {
  final textCtrl = TextEditingController();
  final qtyCtrl = TextEditingController();
  final searchCtrl = TextEditingController();
  bool showBought = true;

  @override
  void dispose() {
    textCtrl.dispose();
    qtyCtrl.dispose();
    searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentFamilyAsync = ref.watch(currentFamilyIdProvider);
    final repo = ref.watch(repositoriesProvider);

    return currentFamilyAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Error: $e')),
      data: (familyId) {
        if (familyId == null) {
          return Center(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.family_restroom, size: 48),
                    const SizedBox(height: 12),
                    const Text('Primero crea o selecciona una familia.'),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: () => context.go('/family-setup'),
                      child: const Text('Gestionar familias'),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        return StreamBuilder(
          stream: repo.shopping(familyId),
          builder: (context, snapshot) {
            final allItems = snapshot.data ?? [];
            final query = searchCtrl.text.trim().toLowerCase();
            final items = allItems.where((item) {
              final matchesQuery = query.isEmpty ||
                  item.text.toLowerCase().contains(query) ||
                  (item.qty ?? '').toLowerCase().contains(query);
              final matchesBought = showBought || !item.isDone;
              return matchesQuery && matchesBought;
            }).toList();

            final pending = allItems.where((e) => !e.isDone).length;
            final bought = allItems.where((e) => e.isDone).length;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text('Compra', style: Theme.of(context).textTheme.headlineMedium),
                    const Spacer(),
                    IconButton(
                      tooltip: 'Eliminar comprados',
                      onPressed: bought == 0
                          ? null
                          : () async {
                              final ok = await showDialog<bool>(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('Eliminar comprados'),
                                  content: Text('Se eliminarán $bought productos marcados.'),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(context, false),
                                      child: const Text('Cancelar'),
                                    ),
                                    FilledButton(
                                      onPressed: () => Navigator.pop(context, true),
                                      child: const Text('Eliminar'),
                                    ),
                                  ],
                                ),
                              );
                              if (ok == true) await repo.clearBoughtShopping(familyId);
                            },
                      icon: const Icon(Icons.cleaning_services_outlined),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    Chip(label: Text('Pendientes: $pending')),
                    Chip(label: Text('Comprados: $bought')),
                    FilterChip(
                      label: const Text('Mostrar comprados'),
                      selected: showBought,
                      onSelected: (value) => setState(() => showBought = value),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              flex: 3,
                              child: TextField(
                                controller: textCtrl,
                                decoration: const InputDecoration(
                                  labelText: 'Producto',
                                  border: OutlineInputBorder(),
                                ),
                                onSubmitted: (_) => _addItem(familyId),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: TextField(
                                controller: qtyCtrl,
                                decoration: const InputDecoration(
                                  labelText: 'Cantidad',
                                  border: OutlineInputBorder(),
                                ),
                                onSubmitted: (_) => _addItem(familyId),
                              ),
                            ),
                            const SizedBox(width: 8),
                            FilledButton.icon(
                              onPressed: () => _addItem(familyId),
                              icon: const Icon(Icons.add),
                              label: const Text('Añadir'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: searchCtrl,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.search),
                            labelText: 'Buscar en la lista',
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (_) => setState(() {}),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: snapshot.connectionState == ConnectionState.waiting
                      ? const Center(child: CircularProgressIndicator())
                      : items.isEmpty
                          ? Center(
                              child: Text(
                                allItems.isEmpty
                                    ? 'La lista está vacía. Añade el primer producto.'
                                    : 'No hay productos con ese filtro.',
                              ),
                            )
                          : ListView.separated(
                              itemCount: items.length,
                              separatorBuilder: (_, __) => const Divider(height: 1),
                              itemBuilder: (context, index) {
                                final item = items[index];
                                return CheckboxListTile(
                                  value: item.isDone,
                                  onChanged: (_) => repo.toggleShopping(item),
                                  title: Text(
                                    item.text.isEmpty ? 'Producto sin nombre' : item.text,
                                    style: TextStyle(
                                      decoration: item.isDone
                                          ? TextDecoration.lineThrough
                                          : null,
                                    ),
                                  ),
                                  subtitle: item.qty == null || item.qty!.isEmpty
                                      ? null
                                      : Text(item.qty!),
                                  secondary: IconButton(
                                    icon: const Icon(Icons.delete_outline),
                                    onPressed: () => repo.deleteShopping(item.id),
                                  ),
                                );
                              },
                            ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _addItem(String familyId) async {
    final repo = ref.read(repositoriesProvider);
    final text = textCtrl.text.trim();
    if (text.isEmpty) return;
    await repo.addShopping(
      familyId: familyId,
      text: text,
      qty: qtyCtrl.text.trim().isEmpty ? null : qtyCtrl.text.trim(),
    );
    textCtrl.clear();
    qtyCtrl.clear();
  }
}
